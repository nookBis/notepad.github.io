# Notepad

### Learn how to make this Notepad app by watching my [Beginner Software Developer Course](https://michaelsboost.github.io/Beginner-Software-Developer-Course/)!